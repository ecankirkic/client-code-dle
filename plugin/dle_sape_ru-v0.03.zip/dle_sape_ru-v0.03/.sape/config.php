<?php

$sape_config = array();